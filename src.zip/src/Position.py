class Position:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    @staticmethod
    def string_to_pos(string):
        x_y = string[1:len(string)-2].split(",")
        return Position(int(x_y[0]), int(x_y[1]))
    
    def __str__(self):
        return "(" + self.x.__str__() + ", " + self.y.__str__() + ")"