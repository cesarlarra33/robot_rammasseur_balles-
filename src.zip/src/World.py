import numpy as np
from Position import *
from Obstacle import *
from itertools import permutations
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import math
import sys


default_n = 50
default_robot_position = Position(9, 9)
default_vitesse_rotation = 1
default_vitesse_deplacement = 1

class World:
    def __init__(self, n, robot, garbages, robot_angle=(math.pi/2), obstacles = []):
        self.n = n
        self.robot = robot
        self.garbages = garbages
        self.robot_angle = robot_angle
        self.obstacles = obstacles

    @staticmethod
    def load_from_file(path_file, n):
        robot_position = default_robot_position
        garbages = []
        obstacles = []
        with open(path_file, 'r') as file:
            for line in file:
                tab = line.split(" : ")
                if (tab[0] == "R"):
                    robot_position = Position.string_to_pos(tab[1])
                elif (tab[0].isdigit()):
                    garbages.append(Position.string_to_pos(tab[1]))
                elif (tab[0] == "X"):
                    obstacles.append(Obstacle.string_to_obstacle(tab[1]))
        return World(n, robot_position, garbages, obstacles=obstacles)
    
    def world_graph(self):
        x_coords = []
        y_coords = []
        rectangles = []
        for i in range(len(self.garbages)):
            x_coords.append(self.garbages[i].x)
            y_coords.append(self.garbages[i].y)
        
        for i in range(len(self.obstacles)):
            rectangles.append(patches.Rectangle((self.obstacles[i].down_left.x, self.obstacles[i].up_right.y), self.obstacles[i].up_right.x - self.obstacles[i].down_left.x, self.obstacles[i].down_left.y - self.obstacles[i].up_right.y, linewidth=1, edgecolor='r', facecolor='r'))
        fig, ax = plt.subplots()
        ax.scatter(x_coords, y_coords)
        ax.scatter(self.robot.x, self.robot.x)
        for rectangle in rectangles:
            ax.add_patch(rectangle)
        plt.savefig('world.jpg')
    
    def calcul_distances(self, n, all_positions, obstacles=[]):
        distances = np.zeros((n,n))
        for i in range(n):
            for j in range(i + 1, n):
                crossing = False
                for k in range(len(obstacles)):
                    if (obstacles[k].is_crossed(all_positions[i], all_positions[j])):
                        crossing = True
                        distances[i][j] = -k
                        distances[j][i] = -k
                if not crossing:
                    distance = ((all_positions[i].x - all_positions[j].x)**2 + (all_positions[i].y - all_positions[j].y)**2)**0.5
                    distances[i][j] = distance
                    distances[j][i] = distance
        return distances

    def calibrer_angle(self, angle):
        if angle > math.pi:
            angle -= 2 * math.pi
        elif angle < -math.pi:
            angle += 2 * math.pi
        return angle

    def calculer_angle_rotation(self, position_actuelle, angle_actuel, position_cible):
        # Calcul de la différence des coordonnées x et y entre la position cible et la position actuelle
        diff_x = position_cible.x - position_actuelle.x
        diff_y = position_cible.y - position_actuelle.y

        # Calcul de l'angle en radian entre la position actuelle et la position cible
        angle_cible = math.atan2(diff_y, diff_x)

        # Calcul de la différence d'angle entre l'angle actuel et l'angle cible
        angle_rotation = angle_cible - angle_actuel

        # Ajustement de l'angle de rotation dans la plage [-pi, pi]
        return self.calibrer_angle(angle_rotation)
        
        return angle_rotation

    def tsp(self, vitesse_deplacement = 1, vitesse_rotation = 1):
        all_positions = [self.robot] + self.garbages
        n = len(all_positions)

        # Calcul des distances et angles entre les positions
        distances = self.calcul_distances(n, all_positions)

        # Recherche de la permutation optimale des positions
        best_permutation = None
        best_distance = float('inf')
        for permutation in permutations(range(1, n)):
            #current_pos = self.robot
            current_angle = self.robot_angle
            distance = distances[0][permutation[0]]
            for i in range(len(permutation)-1):
                #on calcul l'angle de rotation
                distance, current_angle = self.next_step(all_positions[permutation[i]], all_positions[permutation[i+1]], current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            distance, current_angle = self.next_step(all_positions[permutation[-1]], all_positions[permutation[0]], current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            if distance < best_distance:
                best_distance = distance
                best_permutation = permutation

        # Construction du chemin optimal
        path = [self.robot]
        for i in range(len(best_permutation)):
            current_position = all_positions[best_permutation[i]]
            path.append(current_position)
        path.append(self.robot)

        return path
    
    def next_step(self, src, dst, current_angle, current_dist,vitesse_deplacement = 1, vitesse_rotation = 1):
        rotation = self.calculer_angle_rotation(src, current_angle, dst)
        distance = ((src.x - dst.x)**2 + (src.y - dst.y)**2)**0.5 * vitesse_deplacement + vitesse_rotation * rotation
        current_angle = self.calibrer_angle(current_angle + rotation)
        return current_dist + distance, current_angle

    def path_with_obstacle(self, obstacle, src, dst, current_angle, vitesse_deplacement = 1, vitesse_rotation = 1):
        points = [obstacle.down_left, obstacle.up_right, Position(obstacle.down_left.x, obstacle.up_right.y), Position(obstacle.up_right.x, obstacle.down_left.y)]
        src_can_access_to = []
        dst_can_access_to = []
        for p in points:
            if (not obstacle.is_crossed(src, p)):
                src_can_access_to.append(p)
            if (not obstacle.is_crossed(dst, p)):
                dst_can_access_to.append(p)
        
        intersection = list(set(src_can_access_to) & set(dst_can_access_to))
        
        if (len(intersection) > 0):
            path = [src, intersection[0], dst]
            distance = 0
            distance, current_angle = self.next_step(src, intersection[0],  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            distance, current_angle = self.next_step(intersection[0], dst,  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            return path, distance, current_angle
        else:
            next_point = self.nearest_position(src, src_can_access_to, current_angle, vitesse_deplacement = vitesse_deplacement, vitesse_rotation = vitesse_rotation)
            next_can_access_to = []
            points.remove(next_point)
            for p in points:
                if (not obstacle.is_crossed(next_point, p)):
                    next_can_access_to.append(p)
            intersection = list(set(next_can_access_to) & set(dst_can_access_to))
            path = [src, next_point, intersection[0], dst]
            distance = 0
            #première étape
            distance, current_angle = self.next_step(src, next_point,  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            #deuxième étape
            distance, current_angle = self.next_step(next_point, intersection[0],  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            #troisième étape
            distance, current_angle = self.next_step(intersection[0], dst,  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            return path, distance, current_angle
    
    def tsp_obstacles(self, vitesse_deplacement = 1, vitesse_rotation = 1):
        all_positions = [self.robot] + self.garbages
        n = len(all_positions)

        # Calcul des distances et angles entre les positions
        distances = self.calcul_distances(n, all_positions, obstacles=self.obstacles)
        best_distance = float('inf')
        best_path = []
        for permutation in permutations(range(1, n)):
            current_angle = self.robot_angle
            path = []
            distance = distances[0][permutation[0]]
            for i in range(len(permutation)-1):
                if distances[permutation[i]][permutation[i+1]] <= 0:
                    temp_p, temp_d, temp_a = self.path_with_obstacle(self.obstacles[int(-1 * distances[permutation[i]][permutation[i+1]])], all_positions[permutation[i]], all_positions[permutation[i+1]], current_angle, vitesse_deplacement = vitesse_deplacement, vitesse_rotation = vitesse_rotation)
                    distance += vitesse_deplacement * temp_d
                    current_angle = temp_a
                    for p in temp_p:
                        path.append(p)
                else:
                    path.append(all_positions[permutation[i]])
                    path.append(all_positions[permutation[i+1]])
                    distance, current_angle = self.next_step(all_positions[permutation[i]], all_positions[permutation[i+1]],  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            if distances[permutation[-1]][permutation[0]] <= 0:
                temp_p, temp_d, temp_a = self.path_with_obstacle(self.obstacles[int(-1 * distances[permutation[-1]][permutation[0]])], all_positions[permutation[-1]], all_positions[permutation[0]], current_angle, vitesse_deplacement = vitesse_deplacement, vitesse_rotation = vitesse_rotation)
                distance += vitesse_deplacement *temp_d
                current_angle = temp_a
                for p in temp_p:
                    path.append(p)
            else :
                path.append(all_positions[permutation[-1]])
                path.append(all_positions[permutation[0]])
                distance, current_angle = self.next_step(all_positions[permutation[-1]], all_positions[permutation[0]],  current_angle, distance, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            if distance < best_distance:
                best_distance = distance
                best_path = path
        return best_path
    
    def nearest_position(self, current_pos, left_pos, current_angle, vitesse_deplacement = 1, vitesse_rotation = 1):
        nearest_pos = None
        min_dist = float('inf')
        for position in left_pos:
            dist = vitesse_deplacement * ((current_pos.x - position.x)**2 + (current_pos.y - position.y)**2)**0.5 + vitesse_rotation * self.calculer_angle_rotation(current_pos, current_angle, position)
            current_angle = self.calibrer_angle(current_angle + self.calculer_angle_rotation(current_pos, current_angle, position))
            if dist < min_dist:
                nearest_pos = position
                min_dist = dist
        return nearest_pos
    
    def tsp_glouton(self,  vitesse_deplacement = 1, vitesse_rotation = 1):
        path = [self.robot]
        positions = self.garbages
        while positions:
            nearest_pos = self.nearest_position(path[len(path) - 1], positions, vitesse_deplacement=vitesse_deplacement, vitesse_rotation=vitesse_rotation)
            positions.remove(nearest_pos)
            path.append(nearest_pos)
        path.append(self.robot)
        return path

    def tsp_graph(self, tsp):
        x_coords = []
        y_coords = []
        rectangles = []
        path = tsp(vitesse_deplacement=default_vitesse_deplacement, vitesse_rotation=default_vitesse_rotation)
        for i in range(len(path)):
            x_coords.append(path[i].x)
            y_coords.append(path[i].y)

        for i in range(len(self.obstacles)):
            rectangles.append(patches.Rectangle((self.obstacles[i].down_left.x, self.obstacles[i].up_right.y), self.obstacles[i].up_right.x - self.obstacles[i].down_left.x, self.obstacles[i].down_left.y - self.obstacles[i].up_right.y, linewidth=1, edgecolor='r', facecolor='r'))
        fig, ax = plt.subplots()
        ax.plot(x_coords, y_coords)
        for rectangle in rectangles:
            ax.add_patch(rectangle)
        plt.savefig("tsp.jpg")






if __name__ == "__main__":
    w = World.load_from_file("test_world.txt", default_n)
    default_tsp = w.tsp
    default_n = 50
    default_vitesse_rotation = 1
    default_vitesse_deplacement = 1

    w.tsp_graph(default_tsp)

