from Position import *

class Obstacle:
    def __init__(self, x1, y1, x2, y2):
        self.down_left = Position(x1, y1)
        self.up_right = Position(x2, y2)

    def __init__(self, pos1, pos2):
        self.down_left = pos1
        self.up_right = pos2

    @staticmethod
    def string_to_obstacle(string):
        tab = string.split(";")
        pos1 = Position.string_to_pos(tab[0])
        pos2 = Position.string_to_pos(tab[1])
        return Obstacle(pos1=pos1, pos2=pos2)
    
    def is_crossed(self, pos1, pos2):
        x1 = pos1.x
        x2 = pos2.x
        y1 = pos1.y
        y2 = pos2.y
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)

        sx = -1 if x1 > x2 else 1
        sy = -1 if y1 > y2 else 1

        err = dx - dy

        while x1 != x2 or y1 != y2:
            if x1 > self.down_left.x and x1 < self.up_right.x and y1 > self.down_left.y and y1 < self.up_right.y:
                return True
            
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x1 += sx
            if e2 < dx:
                err += dx
                y1 += sy
        
        return False
    
    def __str__(self):
        return "(" + self.up_right.__str__() + ", "  + self.down_left.__str__() + ")"
